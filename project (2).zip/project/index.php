<?php

session_start();
require_once 'common/checkAuth.php';
require_once 'common/connect.php';

$categories = getCategories();

$search = $_POST['search'] ?? '';

if($search){
    $posts = searchPosts($search);
}
else {
    
   $catId = $_GET['cat_id'] ?? null;

   if($catId)
     $posts = getPosts($catId);
   else
     $posts = getPosts();
}
?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

        <title>Homepage</title>
        <!-- Core theme CSS (includes Bootstrap)-->
        <?php require_once 'common/included.php'; ?>
   
<style>

/* Стили для заголовка "Recommendations" */
header {
  background-color: #343a40; /* Цвет фона */
  padding: 80px 0; /* Отступы сверху и снизу */
  text-align: center;
}

header h1 {
  color: #ffffff; /* Цвет текста */
  font-size: 3rem; /* Размер шрифта */
}

/* Стили для карточек постов */
.card {
  border: 1px solid #dee2e6; /* Граница карточки */
  border-radius: 10px; /* Радиус скругления углов */
  margin-bottom: 20px; /* Отступ снизу */
  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1); /* Тень для карточки */
  transition: transform 0.3s ease; /* Плавное изменение при наведении */
}

.card:hover {
  transform: translateY(-5px); /* Анимация поднятия при наведении */
}

.card-img-top {
  border-top-left-radius: 10px; /* Радиус скругления верхних углов у изображения */
  border-top-right-radius: 10px;
}

.card-body {
  padding: 20px; /* Отступы внутри */
}

.card-body h5 {
  color: #343a40; /* Цвет заголовка поста */
  font-size: 1.5rem; /* Размер шрифта заголовка */
  margin-bottom: 15px; /* Отступ снизу */
}

.card-body p {
  color: #6c757d; /* Цвет текста поста */
  font-size: 1.1rem; /* Размер шрифта текста */
}

.card-footer {
  background-color: #f8f9fa; /* Цвет фона футера карточки */
  padding: 15px 20px; /* Отступы внутри */
  display: flex; /* Использовать flexbox для расположения элементов */
  justify-content: space-between; /* Распределить элементы по горизонтали с промежутком между ними */
  align-items: center; /* Выравнивание элементов по центру по вертикали */
  border-bottom-left-radius: 10px; /* Радиус скругления углов футера */
  border-bottom-right-radius: 10px;
}

.btn {
  text-transform: uppercase; /* Преобразовать текст кнопок в верхний регистр */
  font-size: 0.9rem; /* Размер шрифта кнопок */
  padding: 8px 20px; /* Отступы внутри кнопок */
  border-radius: 5px; /* Радиус скругления углов кнопок */
}

.btn-outline-dark {
  color: #343a40; /* Цвет текста кнопки */
  border: 1px solid #343a40; /* Цвет рамки */
}

.btn-outline-dark:hover {
  background-color: #343a40; /* Цвет фона при наведении */
  color: #ffffff; /* Цвет текста при наведении */
}

.btn-outline-danger {
  color: #721c24; /* Цвет текста красной кнопки */
  border: 1px solid #721c24; /* Цвет рамки красной кнопки */
}

.btn-outline-danger:hover {
  background-color: #721c24; /* Цвет фона при наведении */
  color: #ffffff; /* Цвет текста при наведении */
}

/* Стили для футера */
footer {
  background-color: #343a40; /* Цвет фона */
  color: #ffffff; /* Цвет текста */
  padding: 20px 0; /* Отступы сверху и снизу */
  text-align: center; /* Выравнивание текста по центру */
}


.col form{
   display: inline;

   
}

.navbar-brand {
  font-size: 24px;
  font-weight: bold;
  color: #333; /* Change color as needed */
}

/* Navbar Links */
.navbar-nav .nav-link {
  font-size: 16px;
  color: #555; /* Change color as needed */
  margin-right: 15px;
}

/* Active Link */
.nav-item.active .nav-link {
  color: #f00; /* Change color for active link */
}

/* Dropdown */
.dropdown-menu {
  background-color: #f9f9f9; /* Change background color */
  border: 1px solid #ccc; /* Change border color */
}

.dropdown-menu a {
  color: #333; /* Change color as needed */
}

/* Avatar */
.avatar {
  width: 40px; /* Set your preferred width */
  height: 40px; /* Set your preferred height */
  border-radius: 50%; /* To make it round */
}

</style>
    </head>
    <body>
        
        <?php 
        if ($user['role']=='user') {
          require_once 'common/nav.php';
        }
        else {
          require_once 'common/navAdmin.php';
        }
         ?>
        <!-- Header-->
        <header class="bg-dark py-3">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">ALA shop</h1>
                </div>
            </div>
        </header>
        <!-- Section-->
        <section class="py-5">
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">

               <?php foreach($posts as $post): ?>

                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="images/postimg/<?=$post['image']?>" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder"><?= $post['title']; ?></h5>
                                    <!-- Product price-->
                                    <?= $post['content']; ?>
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <a class="btn btn-outline-dark mt-auto" href="onePost.php?post_id=<?= $post['id']; ?>">Read</a>
                             

                                <?php   if($post['user_id'] == $user['id']):  ?>
                                     <a class="btn btn-outline-dark mt-auto" href="editPostform.php?post_id=<?= $post['id']; ?>">Edit</a>  

                                <form onsubmit="return confirm('really want to delete?')" action="deletePost.php" method="post">
                                 <input type="hidden" name="post_id" value=" <?= $post['id'] ?>">
                                 <button class="btn btn-outline-danger mt-auto" type="submit">
                                    Delete
                                 </button>
                                </form>

                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
               <?php endforeach; ?>
                </div>
            </div>
        </section>




        
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
