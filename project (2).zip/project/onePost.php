<?php

session_start();
require_once 'common/checkAuth.php';
require_once 'common/connect.php';

$categories = getCategories();

$postId = $_GET['post_id'] ?? null;

if ($postId) {
    $post = getOnePost($postId);

    if (!$post) {

    }
}
?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>Homepage</title>
        <!-- Core theme CSS (includes Bootstrap)-->
        <?php require_once 'common/included.php'; ?>
    </head>

    <body>
        <?php require_once 'common/nav.php' ?>
        <!-- Header-->
        <header class="bg-dark py-3">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Recommendations</h1>
                </div>
            </div>
        </header>

    <section class="py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="row gx-4 gx-lg-5 align-items-center">
                    <div class="col-md-6"><img class="card-img-top mb-5 mb-md-0" src="images/postimg/<?=$post['image']?>" alt="..." /></div>
                    <div class="col-md-6">
                        <div class="small mb-1">New</div>
                        <h1 class="display-5 fw-bolder"><?= isset($post['title']) ? $post['title'] : 'No Title' ?></h1>
                        <div class="fs-5 mb-5">
                        </div>
                        <p class="lead"><?= isset($post['content']) ? $post['content'] : 'No Content' ?></p>


                    <h3>
                        <?php
                              $avg = countAvg($post['id']);
                              if(isset($avg['rating']))
                              echo round($avg['rating'], 2);
                            else
                            echo "Not rated";
                        ?>
                    </h3>

                        <form action="rate.php" method="POST">
                        <div class="mb-3">
                           <label for="disabledSelect" class="form-label">Disabled select menu</label>
                           <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                           <select name="rating" id="disabledSelect" class="form-select mb-3">
                              <option valeu="1">1 (very bad)</option>
                              <option valeu="2">2 (bad)</option>
                              <option valeu="3">3 (ok)</option>
                              <option valeu="4">4 (good)</option>
                              <option valeu="5">5 (very good)</option>
                            </select>
                            <button type="submit" class="btn btn-primary mb-3">Rate</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
    </section>
    

        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
