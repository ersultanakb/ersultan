<?php
try{
    $pdo = new PDO("mysql:host=localhost; port=3306; dbname=proj", "root", "");
}
catch (PDOException $ex){
    echo $ex -> getMessage();
}
function loginUser($email, $password){
    global $pdo;
    $queryObj = $pdo->prepare("select * from users where email = :uemail and password = :upass");
    try {
       $queryObj->execute([
        'uemail' => $email,
        'upass' => md5($password)
    ]); 
    } catch (PDOException $ex) {
        return false;
    }
    $user = $queryObj->fetch(PDO::FETCH_ASSOC);
    return $user;
}

function registerUser($email, $password, $name, $role='user'){

    global $pdo;
    $queryObj = $pdo->prepare("insert into users(email, password, name, role, avatar) values(:ue, :up, :un, :ur, :ua)");

    try {
        $queryObj->execute([
            'ue' => $email,
            'up' => md5($password),
            'un' => $name,
            'ur' => $role,
            'ua' => $avatar,
        ]);
    }catch(PDOException $ex){
        echo $ex->getMessage();
        return false;
    }
    return true;
}

function getCategories(){
    global $pdo;
    $queryObj = $pdo->query("select * from categories");

    $categories = $queryObj->fetchAll(PDO::FETCH_ASSOC);
    return $categories;
}

function createPost($title, $content, $category_id, $user_id, $image='no-img.jpg' ,$status='draft'){
    global $pdo;
    $queryObj = $pdo->prepare("insert into posts(title, content, category_id, user_id, status, image, created_at) values (:ptt, :pcn, :pci, :pui, :pst, :pim, :pca)");
    
    date_default_timezone_set('Asia/Almaty');
    
    try {
        $queryObj->execute([
            'ptt' => $title,
            'pcn' => $content,
            'pci' => $category_id,
            'pui' => $user_id,
            'pst' => $status,
            'pim' => $image,
            'pca' => date("Y-m-d H:i:s", time())
        ]);
    } catch (PDOException $ex) {
        return false;
    }
    return true;
}


function getPosts($catId = null){
    global $pdo;

    if($catId){
        $queryObj = $pdo->prepare("select * from posts where category_id = ?");
    $queryObj->execute([$catId]);
    }
    else{
        $queryObj = $pdo->query("select * from posts");
    }
    $posts = $queryObj->fetchAll(PDO::FETCH_ASSOC);
    return $posts;
}


function getOnePost($postId){
    global $pdo;

    $queryObj = $pdo->prepare("select * from posts where id = ?");
    $queryObj->execute([$postId]);
    
    $post = $queryObj->fetch(PDO::FETCH_ASSOC);
    return $post;
}


function editPost($id, $title, $content, $category_id, $status='draft', $image='no-img.jpg'){
    global $pdo;
    $queryObj = $pdo->prepare("update posts SET title = :ptt, content = :pcn, category_id = :pci, status = :pst, image = :pim  where id = :pid");
    
    date_default_timezone_set('Asia/Almaty');
    
    try {
        $queryObj->execute([
            'pid' => $id,
            'ptt' => $title,
            'pcn' => $content,
            'pci' => $category_id,
            'pst' => $status,
            'pim' => $image,
        ]);
    } catch (PDOException $ex) {
        return false;
    }
    return true;
}

function deletePost($postId){
    global $pdo;

    $queryObj = $pdo->prepare("delete from posts where id = ?");
    $result = $queryObj->execute([$postId]);
    
    $post = $queryObj->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function newregisterUser($password, $newpassword, $newpassword2, $role='user', $avatar='no-avatar.jpg'){
    global $pdo;
    $queryObj = $pdo->prepare("insert into users($password, $newpassword, $newpassword2, role, avatar) values (:upass, :unewpass, :unewpass2, :urole, :uava)");
    try {
        $queryObj->execute([
            'unewpass' => $newpassword,
            'unewpass2' => $newpassword2,
            'urole' => $role,
            'uava' => $avatar,
            'upass' => md5($password)
        ]);
    } catch (PDOException $ex) {
        return false;
    }
    return true;
}

function changePassword($id, $newPassword){
    global $pdo;
    $hashedPassword = md5($newPassword);
    $queryObj = $pdo->prepare("UPDATE users SET password = :upass WHERE id = :uid");
 
    try{
        $queryObj->execute([
            "upass" => $hashedPassword,
            "uid" => $id
        ]); 
    }
    catch (PDOException $e) {
        return $e;
    }
}



function searchPosts($search){
    global $pdo;

    if($search){
        $queryObj = $pdo->prepare("SELECT * FROM posts WHERE title LIKE :search OR content LIKE :search");
        $queryObj->execute(['search' => '%'.$search.'%']);
    }
    else{
        $queryObj = $pdo->query("SELECT * FROM posts");
    }

    $posts = $queryObj->fetchAll(PDO::FETCH_ASSOC);
    return $posts;
}

function ratePost($user_id, $post_id, $rating){
    global $pdo;

    // Check if $post_id is not empty
    if (empty($post_id)) {
        return false; // or handle the empty case as needed
    }

    $queryObj = $pdo->prepare("SELECT * FROM user_post WHERE uid=:uid AND pid=:pid");
    $queryObj->execute([
        'uid' => $user_id,
        'pid' => $post_id
    ]);
    $result = $queryObj->fetch(PDO::FETCH_ASSOC);

    if($result){
        $queryObj = $pdo->prepare("UPDATE user_post SET rating=:rating WHERE uid=:uid AND pid=:pid");
    } else {
        $queryObj = $pdo->prepare("INSERT INTO user_post(uid, pid, rating) VALUES(:uid, :pid, :rating)");
    }

    try {
        $queryObj->execute([
            'uid' => $user_id,
            'pid' => $post_id,
            'rating' => $rating
        ]);
    } catch(PDOException $ex) {
        echo $ex->getMessage();
        return false;
    }
    return true;
}


function countAvg($post_id){
    global $pdo;

    $queryObj = $pdo->prepare("SELECT AVG(rating) AS rating FROM user_post WHERE pid = :pid");

    try {
        $queryObj->execute([
            'pid' => $post_id,
        ]);
    } catch(PDOException $ex) {
        echo $ex->getMessage();
        return false;
    }

    $result = $queryObj->fetch(PDO::FETCH_ASSOC);
    return $result;
}

?>




