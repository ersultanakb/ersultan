<style>
    /* Navbar Brand */
.navbar-brand {
  font-size: 24px;
  font-weight: bold;
  color: #333; /* Change color as needed */
}

/* Navbar Links */
.navbar-nav .nav-link {
  font-size: 16px;
  color: #555; /* Change color as needed */
  margin-right: 15px;
}

/* Active Link */
.nav-item.active .nav-link {
  color: #f00; /* Change color for active link */
}

/* Dropdown */
.dropdown-menu {
  background-color: black; /* Change background color */
  border: 1px solid #ccc; /* Change border color */
}

.dropdown-menu a {
  color: #333; /* Change color as needed */
}

/* Avatar */
.avatar {
  width: 40px; /* Set your preferred width */
  height: 40px; /* Set your preferred height */
  border-radius: 50%; /* To make it round */
}

</style>



<nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
            
                <a class="navbar-brand" href="#!">ALA Bank</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
                        <!-- <li class="nav-item"><a class="nav-link" href="createPostForm.php">Create</a></li> -->
                        <li class="nav-item dropdown">
                        <li class="nav-item"><a class="nav-link" href="update.php">update-P</a></li>
                        <form class="ms-3" action="logout.php" method="post">
                        <button class="btn btn-gray" type="submit">Logout</button>
                        </form>
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Categories</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <div class="card-header"></div>
                                  <div class="card-body">
                                      <form action="index.php" method="post">
                                      <div class="input-group">
                                          <input name="search" class="form-control" type="text" planeholder="Enterc search term..." aria-label="Enter search term..." />
                                          <button class="btn btn-primary" id="button-search" type="submit">Go</button>
                                        </div>
                                         </form>
                              </div>
                              <?php foreach($categories as $cat): ?>
                                <li><a class="dropdown-item" href="index.php?cat_id=<?= $cat['id']; ?>"><?= $cat['nameen']; ?></a></li>
                              <?php endforeach; ?>   
                              
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>