<?php
session_start();

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['old_password'])&& isset($_POST['new_password'])&& isset($_POST['confirm_password'])) {
       $old_password = $_POST['old_password'];
       $new_password = $_POST['new_password'];
       $confirm_password = $_POST['confirm_password'];
   
       $error = [];
   
       if(empty($old_password)) {
           $error['old_password'] = 'old password is empty';
       }
   
        else{
               if(strlen($old_password) < 6){
                   $error['old_password'] = "Current password must be at least 6 characters";
                   }
                   else{
                       if(!preg_match('/[A-Z]/', $old_password) || !preg_match('/[a-z]/', $old_password) ||!preg_match('/[0-9]/', $old_password)) {
                       $error['old_password'] = "/[A-Z]//[a-z]//[0-9]/";
                       }
                       else{
                           if(md5($old_password)!= $_SESSION['user']['password']) {
                              $error['old_password'] = "<span class='spans'>You are password is not correct</span>";
                              header('Location: update.php');
                           }
                       }
                   }
           }
   
        if(empty($new_password)){
            $error['new_password'] = 'New password is empty';
        }
           else{
               if(strlen($new_password) < 6){
                   $error['new_password'] = "New password must be at least 6 characters";
               }
           
               else {
                   if(!preg_match('/[A-Z]/', $new_password) || !preg_match('/[a-z]/', $new_password) || !preg_match('/[0-9]/', $new_password)) {
                        $error['new_password'] = "/[A-Z]//[a-z]//[0-9]/";
                   }
               }
           }
   
           if(empty($confirm_password)){
               $error['confirm_password'] = 'Confirm password is empty';
            }
            else{
                if(strlen($confirm_password) < 6){
                    $error['confirm_password'] = "Confirm password must be at least 6 characters";
                }
                 else{
                     if(!preg_match('/[A-Z]/', $confirm_password) ||!preg_match('/[a-z]/', $confirm_password) ||!preg_match('/[0-9]/', $confirm_password)) {
                         $error['confirm_password'] = "/[A-Z]//[a-z]//[0-9]/";
                     }
                 }
            }
   
           if($new_password!=$confirm_password){
               $error['confirm_password'] = 'Passwords do not match';
           }
   
           else{
               if($error){
                   $_SESSION['error'] = $error;
                   header('Location: update.php');
               }
               else{
                    if($old_password == $new_password && $new_password == $confirm_password) {
                        $_SESSION['MainError'] = "<span class='kate'>your new password should be different from your current one</span>";
                        header('Location: update.php');
                    }
                    else{
                        include_once("common/connect.php");
                        changePassword($_SESSION['user']['id'], $new_password);
                        header('Location: index.php');
                        $_SESSION['user']['password'] = md5($new_password);
                        $_SESSION['MainError'] = "<span class='duris'>Congratulations you changed your password </span>";
                    }
                }
            }
       }
    }
   
   else{
           header("Location: loginForm.php");
       }
?>
